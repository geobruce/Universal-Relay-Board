#!/bin/bash
git push --all gso && git push --all github
git push --tags gso && git push --tags github

