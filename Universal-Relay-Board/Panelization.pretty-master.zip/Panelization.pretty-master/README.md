
Panelization.pretty
===================

LAYOUT FILES: KiCad footprints useful for PCB panelization (mouse-bites...).

